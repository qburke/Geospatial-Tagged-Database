# Geospatial Data-querying

A tag and coordinate-based database with r-nearest neighbor search capabilities

## Features
- Store location and tag based data
- Perform r-nearest neighbor queries along with tag-based search queries
- Efficient implementation
